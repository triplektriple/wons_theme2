export const SESSION_STORAGE_KEY = 'st-ai-builder';
